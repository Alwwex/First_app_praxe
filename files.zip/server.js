const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

const app = express();
const PORT = 3000;

app.use(cors()); // Allow all origins on local network
app.use(express.json({ limit: '50mb' })); // Large limit for PDF/base64 images

const upload = multer({ storage: multer.memoryStorage() });

const dbConfig = {
    host: '127.0.0.1',
    user: 'lintech',
    password: '123456',
    database: 'evidence_navstev'
};

// Helper: save signature image to disk
function ulozObrazekNaDisk(id, typ, base64String) {
    try {
        const dir = path.join(__dirname, 'podpisy');
        if (!fs.existsSync(dir)) fs.mkdirSync(dir);
        const cisteBase64 = base64String.replace(/^data:image\/png;base64,/, '');
        fs.writeFileSync(path.join(dir, `${id}_${typ}.png`), cisteBase64, 'base64');
    } catch (err) {
        console.error('Chyba pri zapisu:', err);
    }
}

// --- VISITORS ---

app.get('/api/hledej-osobu', async (req, res) => {
    try {
        const conn = await mysql.createConnection(dbConfig);
        const [rows] = await conn.execute(
            `SELECT n.id, n.jmeno, n.email, n.spolecnost, n.telefon, n.podpis_base64,
                (SELECT d.stav FROM dochazka d WHERE d.navstevnik_id = n.id ORDER BY d.cas_prichodu DESC LIMIT 1) AS posledni_stavy
             FROM navstevnici n WHERE n.jmeno LIKE ? LIMIT 5`,
            [`%${req.query.jmeno}%`]
        );
        await conn.end();
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.json([]);
    }
});

app.post('/api/uloz-navstevnika', async (req, res) => {
    try {
        const { jmeno, email, spolecnost, telefon, podpis } = req.body;
        const conn = await mysql.createConnection(dbConfig);
        const [result] = await conn.execute(
            'INSERT INTO navstevnici (jmeno, email, spolecnost, telefon, podpis_base64) VALUES (?, ?, ?, ?, ?)',
            [jmeno, email, spolecnost, telefon, podpis]
        );
        await conn.end();
        ulozObrazekNaDisk(result.insertId, 'registrace', podpis);
        res.json({ success: true, id: result.insertId });
    } catch (err) {
        console.error(err);
        res.json({ success: false, error: err.message });
    }
});

app.post('/api/zaznamenej-prichod', async (req, res) => {
    try {
        const { navstevnikId, podpisVstup } = req.body;
        const conn = await mysql.createConnection(dbConfig);
        await conn.execute(
            'INSERT INTO dochazka (navstevnik_id, stav, podpis_vstup_base64) VALUES (?, ?, ?)',
            [navstevnikId, 'Uvnitr', podpisVstup]
        );
        await conn.end();
        ulozObrazekNaDisk(navstevnikId, 'vstup', podpisVstup);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.json({ success: false, error: err.message });
    }
});

app.get('/api/nacti-aktivni', async (req, res) => {
    try {
        const conn = await mysql.createConnection(dbConfig);
        const [rows] = await conn.execute(
            `SELECT d.id AS dochazka_id, n.id AS navstevnik_id, n.jmeno, n.spolecnost, n.telefon,
                DATE_FORMAT(d.cas_prichodu, '%H:%i') as cas
             FROM dochazka d
             JOIN navstevnici n ON d.navstevnik_id = n.id
             WHERE d.stav = 'Uvnitr'`
        );
        await conn.end();
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.json([]);
    }
});

app.post('/api/zaznamenej-odchod', async (req, res) => {
    try {
        const { dochazkaId } = req.body;
        const conn = await mysql.createConnection(dbConfig);
        await conn.execute(
            "UPDATE dochazka SET cas_odchodu = CURRENT_TIMESTAMP, stav = 'Odesel' WHERE id = ?",
            [dochazkaId]
        );
        await conn.end();
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.json({ success: false, error: err.message });
    }
});

app.get('/api/nacti-vsechny-cleny', async (req, res) => {
    try {
        const conn = await mysql.createConnection(dbConfig);
        const [rows] = await conn.execute(
            `SELECT n.id, n.jmeno, n.email, n.spolecnost, n.telefon, n.podpis_base64,
                (SELECT d.podpis_vstup_base64 FROM dochazka d WHERE d.navstevnik_id = n.id ORDER BY d.cas_prichodu DESC LIMIT 1) AS posledni_podpis
             FROM navstevnici n ORDER BY n.id DESC`
        );
        await conn.end();
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.json([]);
    }
});

// --- RULES / PRAVIDLA ---

app.get('/api/nacti-pravidla', async (req, res) => {
    try {
        const conn = await mysql.createConnection(dbConfig);
        const [rows] = await conn.execute('SELECT * FROM pravidla ORDER BY poradi ASC');
        await conn.end();
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.json([]);
    }
});

app.post('/api/uloz-pravidlo', async (req, res) => {
    try {
        const { obsah, poradi } = req.body;
        const conn = await mysql.createConnection(dbConfig);
        await conn.execute('INSERT INTO pravidla (obsah, poradi) VALUES (?, ?)', [obsah, poradi]);
        await conn.end();
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.json({ success: false });
    }
});

app.delete('/api/smaz-pravidla', async (req, res) => {
    try {
        const conn = await mysql.createConnection(dbConfig);
        await conn.execute('TRUNCATE TABLE pravidla');
        await conn.end();
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.json({ success: false });
    }
});

app.delete('/api/smaz-stranku/:id', async (req, res) => {
    try {
        const conn = await mysql.createConnection(dbConfig);
        await conn.execute('DELETE FROM pravidla WHERE id = ?', [req.params.id]);
        await conn.end();
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.json({ success: false });
    }
});

// --- PDF UPLOAD (replaces the Electron file picker) ---
// The mobile app will upload the PDF binary directly

app.post('/api/upload-pdf', upload.single('pdf'), async (req, res) => {
    if (!req.file) return res.json({ success: false, error: 'No file' });
    // Return base64 so the frontend can render it with pdf.js exactly as before
    const base64 = req.file.buffer.toString('base64');
    res.json({ success: true, base64 });
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`LINTECH API server running on port ${PORT}`);
});
