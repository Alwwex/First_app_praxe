# LINTECH — Electron → Capacitor (iOS/Android) Migration Guide

## Overview

```
Raspberry Pi (MySQL + API server)  ←→  WiFi  ←→  iPad/Android tablet (Capacitor app)
```

The Electron app is replaced by two parts:
1. **`server.js`** — Express REST API running on the Pi (replaces `main.js` IPC handlers)
2. **Capacitor app** — The same HTML/JS UI, talking to the API over HTTP on the local network

---

## PART 1 — Set up the API server on Raspberry Pi

### 1.1 Copy files to the Pi

Copy `server.js` and `server-package.json` (rename to `package.json`) to a folder on the Pi, e.g. `/home/pi/lintech-server/`.

### 1.2 Install dependencies

```bash
cd /home/pi/lintech-server
npm install
```

### 1.3 Test the server

```bash
node server.js
# Should print: LINTECH API server running on port 3000
```

Test from another device on the same WiFi:
```
http://192.168.1.XXX:3000/api/nacti-aktivni
```
(replace XXX with your Pi's IP — find it with `hostname -I`)

### 1.4 Run as a background service (auto-start on boot)

Install PM2:
```bash
npm install -g pm2
pm2 start server.js --name lintech-api
pm2 save
pm2 startup   # follow the printed command to enable on boot
```

---

## PART 2 — Build the Capacitor mobile app

### 2.1 Prerequisites

On your **Mac or PC** (not the Pi):
- Node.js 18+
- For iOS: macOS + Xcode 15+
- For Android: Android Studio

### 2.2 Create the project

```bash
mkdir lintech-mobile && cd lintech-mobile
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/ios @capacitor/android
npx cap init "LINTECH Recepce" com.lintech.navstevy --web-dir www
```

### 2.3 Add your files

```bash
mkdir www src
# Copy index.html → src/index.html
# Copy logo-lintech-dark.png → src/logo-lintech-dark.png
cp src/index.html www/index.html
cp src/logo-lintech-dark.png www/logo-lintech-dark.png
```

### 2.4 Copy the capacitor.config.ts

Replace the generated `capacitor.config.ts` with the provided one.

### 2.5 Add platforms

```bash
npx cap add ios
npx cap add android
```

### 2.6 Fix Android HTTP (plain HTTP on local network)

Copy `network_security_config.xml` to:
```
android/app/src/main/res/xml/network_security_config.xml
```

Then edit `android/app/src/main/AndroidManifest.xml`, find the `<application>` tag and add:
```xml
android:networkSecurityConfig="@xml/network_security_config"
```

### 2.7 Fix iOS HTTP (ATS — App Transport Security)

In Xcode, open `ios/App/App/Info.plist` and add:
```xml
<key>NSAppTransportSecurity</key>
<dict>
    <key>NSAllowsLocalNetworking</key>
    <true/>
</dict>
```
This allows HTTP on local network only (safe — won't allow internet HTTP).

### 2.8 Sync and open

```bash
npx cap sync
npx cap open ios      # Opens Xcode
npx cap open android  # Opens Android Studio
```

Then build and deploy from Xcode / Android Studio as normal.

---

## PART 3 — First launch on tablet

1. Make sure the tablet is on the **same WiFi** as the Raspberry Pi.
2. Open the app — tap the status indicator in the top-right corner.
3. Enter the Pi's IP address (e.g. `192.168.1.100`) and port `3000`.
4. Tap **Uložit a otestovat** — it will go green if connected.
5. The IP is saved to localStorage — only needs to be set once.

---

## Key differences from the Electron version

| Feature | Electron | Capacitor |
|---|---|---|
| Signature input | Wacom tablet (USB) | Finger/stylus on screen |
| Database access | Direct MySQL from main.js | Via REST API on Pi |
| File picker (PDF) | Electron dialog | Native `<input type="file">` |
| USB repair tool | Linux shell via `exec()` | Not needed (no Wacom) |
| Auto-update | Manual | TestFlight (iOS) / Play Store |

---

## Troubleshooting

**"Connection refused"** — Check that `server.js` is running on the Pi and the Pi's firewall allows port 3000:
```bash
sudo ufw allow 3000
```

**Android shows blank page** — Make sure `network_security_config.xml` is in place and `AndroidManifest.xml` references it.

**iOS shows blank page** — Check `NSAllowsLocalNetworking` is in `Info.plist`.

**PDF import slow** — Normal; pdf.js renders each page to canvas on the device. Large PDFs (20+ pages) may take 30–60 seconds.
