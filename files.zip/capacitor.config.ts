import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.lintech.navstevy',
  appName: 'LINTECH Recepce',
  webDir: 'www',
  server: {
    androidScheme: 'http',
    // Allow HTTP (not HTTPS) since the Pi uses plain HTTP on local network
    cleartext: true,
  },
  ios: {
    allowsLinkPreview: false,
    scrollEnabled: false,
  },
  android: {
    allowMixedContent: true,
  },
};

export default config;
